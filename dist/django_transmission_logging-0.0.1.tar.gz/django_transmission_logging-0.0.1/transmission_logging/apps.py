from django.apps import AppConfig, apps
from django.conf import settings

class TransmissionLoggingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'transmission_logging'
